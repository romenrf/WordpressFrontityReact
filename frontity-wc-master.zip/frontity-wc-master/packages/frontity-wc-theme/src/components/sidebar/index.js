import React from 'react';

const Sidebar = () => (<div>Side bar</div>)

export default Sidebar;