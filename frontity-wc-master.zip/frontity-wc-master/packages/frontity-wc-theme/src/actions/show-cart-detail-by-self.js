export const showCartDetailBySelf = ({ state }) => {
    state.theme.showCartDetailBySelf = true;
}