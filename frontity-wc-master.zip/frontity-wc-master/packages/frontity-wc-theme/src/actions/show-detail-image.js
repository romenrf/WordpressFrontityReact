export const showDetailImage = ({ state }) => {
    state.theme.showDetailImage = true;
}