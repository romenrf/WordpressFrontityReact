export const toggleShowCartDetail = ({ state }) => {
    state.theme.showCartDetail = !state.theme.showCartDetail;
}