export const closeNotifications = ({state}) => {
    state.theme.showNotifications = false;
}