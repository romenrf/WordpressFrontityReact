export const showCartDetailByMenu = ({ state }) => {
    state.theme.showCartDetailByMenu = true;
}