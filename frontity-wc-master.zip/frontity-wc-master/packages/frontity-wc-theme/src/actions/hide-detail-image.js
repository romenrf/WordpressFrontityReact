export const hideDetailImage = ({ state }) => {
    state.theme.showDetailImage = false;
}